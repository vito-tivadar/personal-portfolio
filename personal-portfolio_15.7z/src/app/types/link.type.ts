export type Link = {
  href: string;
  text?: string;
  iconSrc?: string;
};
