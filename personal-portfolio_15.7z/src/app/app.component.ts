import { Component, EventEmitter, Output } from '@angular/core';
import { section } from './types/section.type';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  sections: section[] = [
    {
      title: 'About me',
      description:
        "I'm mechanical engineer and software / web developer. I'm also interested in embedded systems and home automation.",
      projects: [],
    },
    {
      title: 'Mechanical engineering',
      description:
        'In the field of mechanical engineering, I mainly deal with CAD and structural design. Some of the displayed projects were made as hobby and some were school projects.',
      projects: [
        // engine
        // cyberbike
        // custom mouse
        // server rack
      ],
    },
    {
      title: 'Software / Web',
      description:
        'Software and web development interest me since 2014. In the beggining it was just a hobby, but in past few years I am trying to follow diferent design principles to optimize and improve quality of code.',
      projects: [
        // personal portfolio
        // dashboard
        // docker backend
        // Truss FEM Software
        // gps simulator
        // angular modal
        // radio player
        // discord bots
        // tiui ?? rename
      ],
    },
    {
      title: 'Embedded',
      description:
        "Passion for embedded development came from my brother. He is embedded engineer and I was always fascinated with devices he made. In 2020 I picked up new hobby, home automation. When enterprise product doesn't have features I want, I try to create my own device with custom firmware.",
      projects: [
        // dial gauge converter
        // ender 3 rest api
        // server case display with temperature monitoring and fan control
        // custom mouse pcb
      ],
    },
  ];

  @Output('activeSection') activeSection: number = 0;

  generateSectionId(sectionTitle: string): string {
    return sectionTitle.replace(' ', '-').toLowerCase();
  }

  onActiveSectionChange(div: HTMLDivElement) {
    let newActiveSection = Math.round((div.scrollTop / div.scrollHeight) * div.childElementCount);

    this.activeSection = newActiveSection;
  }
}
