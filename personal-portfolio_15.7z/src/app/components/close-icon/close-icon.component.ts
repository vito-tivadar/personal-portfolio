import { Component } from '@angular/core';

@Component({
  selector: 'close-icon',
  templateUrl: './close-icon.component.html',
  styleUrls: ['./close-icon.component.css'],
})
export class CloseIconComponent {}
