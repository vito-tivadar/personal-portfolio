import { Component } from '@angular/core';

@Component({
  selector: 'container-xyz',
  templateUrl: './container-xyz.component.html',
  styleUrls: ['./container-xyz.component.css'],
})
export class ContainerXyzComponent {}
